/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cvsu_clinic_system;

/**
 *
 * @author basba
 */
public class School_Staff_Patient {
    String name, sex, department, position; 
    int idNum, age;
    
    public School_Staff_Patient(String name, int idNum, int age, String sex, String department, String position){
        this.name = name;
        this.idNum = idNum;
        this.age = age;
        this.sex = sex;
        this.department = department;
        this.position = position;
    }
}
