/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cvsu_clinic_system;

/**
 *
 * @author basba
 */
public class Student_Patient {
    String name, sex, strand, section; 
    int idNum, age, gradelevel;
    
    public Student_Patient(String name, int idNum, int age, String sex, String strand, int gradeLevel, String section){
        this.name = name;
        this.idNum = idNum;
        this.age = age;
        this.sex = sex;
        this.strand = strand;
        this.gradelevel = gradeLevel;
        this.section = section;
    }
}
