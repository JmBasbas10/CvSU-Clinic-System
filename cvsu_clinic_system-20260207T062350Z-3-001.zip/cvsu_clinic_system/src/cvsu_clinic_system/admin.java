/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package cvsu_clinic_system;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Image;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import javax.swing.table.DefaultTableModel;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.renderer.category.StandardBarPainter;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author basba
 */
public class admin extends javax.swing.JFrame {
    private int mouseX, mouseY;
    public String selectedUserType, selectedUserID, selectedUserName, selectedUserStrandDepartment, selectedUserPositionSection;

    
    /**
     * Creates new form Admin
     */
    
    
    
    private String url = "jdbc:mysql://localhost:3306/clinic_system";
    private String sqlPass = "jmbasbas";
    
    public admin() {
        initComponents();
        
        ImageIcon appIcon = new ImageIcon("src/images/clinic_logo.png");
        setIconImage(appIcon.getImage());
        setTitle("ALLSHS Clinic - Admin");
        
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 35, 35));
        
        clinic_logo.setIcon(setImage("src/images/clinic_logo.png", clinic_logo));
        logo_label.setIcon(setImage("src/images/allshs_logo.jpg", logo_label));
        minimize_label.setIcon(setImage("src/images/minimize_icon.png", minimize_label));
        close_label.setIcon(setImage("src/images/close_icon.png", close_label));
        viewPassword.setIcon(setImage("src/images/view_icon.png", viewPassword));
        viewPassword1.setIcon(setImage("src/images/view_icon.png", viewPassword1));
        jLabel8.setIcon(setImage("src/images/dashboard_icon.png", jLabel8));
        jLabel18.setIcon(setImage("src/images/admin_icon.png", jLabel18));
        jLabel16.setIcon(setImage("src/images/user_icon.png", jLabel16));
        jLabel14.setIcon(setImage("src/images/patient_icon.png", jLabel14));
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                int x = getLocation().x + e.getX() - mouseX;
                int y = getLocation().y + e.getY() - mouseY;
                
                setLocation(x, y);
            }
        });

    
        showBarChart();
        showPieChart();
        showLineChart();
        
        loadPatientRecordsDataFromDatabase();
        loadUserDataFromDatabase();
        loadAdminDataFromDatabase();
        
        stylePatientRecordsTable();
        styleUserTable();
        styleAdminTable();
        
       
        
        startDateChooser.getDateEditor().getUiComponent().setEnabled(false);
        endDateChooser.getDateEditor().getUiComponent().setEnabled(false);
       
        user_info_table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        
        
        user_info_table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = user_info_table.getSelectedRow();
                if (selectedRow != -1) {
                    Object selectedId = user_info_table.getValueAt(selectedRow, 0);
                    selectedID.setText( selectedId.toString());
                    selectedUserID = selectedId.toString();
                    Object selectedName = user_info_table.getValueAt(selectedRow, 1);
                    selectedUserName = selectedName.toString();
                    Object selectedType = user_info_table.getValueAt(selectedRow, 2);
                    selectedUserType = selectedType.toString();
                    Object selectedStrandDepartment = user_info_table.getValueAt(selectedRow, 3);
                    selectedUserStrandDepartment = selectedStrandDepartment.toString();
                    Object selectedPositionSection= user_info_table.getValueAt(selectedRow, 4);
                    selectedUserPositionSection = selectedPositionSection.toString();
                }
            }
        });
        
        admin_info_table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = admin_info_table.getSelectedRow();
                if (selectedRow != -1) {
                    Object selectedAdminID = admin_info_table.getValueAt(selectedRow, 0); // Fetch ID from column 0
                    adminIDInput.setText( selectedAdminID.toString());
                    Object selectedAdminName = admin_info_table.getValueAt(selectedRow, 1);
                    adminNameInput.setText(selectedAdminName.toString());
                    Object selectedAdminPosition = admin_info_table.getValueAt(selectedRow, 2);
                    adminPositionInput.setText(selectedAdminPosition.toString());
                }
            }
        });
        
        patient_records_table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = patient_records_table.getSelectedRow();
                if (selectedRow != -1) {
                    Object selectedAdminID = patient_records_table.getValueAt(selectedRow, 0); 
                    selectedID1.setText( selectedAdminID.toString());
                    
                }
            }
        });
        
        searchIDInput.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
        searchIDInput1.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
        adminIDInput.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
       
    }
    
    public void showBarChart(){
        String query1 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Nausea = 1";
        String query2 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Difficulty_Breathing = 1";
        String query3 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Muscle_Cramps = 1";
        String query4 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Fatigue = 1";
        String query5 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Stomach_Problems = 1";
        String query6 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Blurry_Vision = 1";
        String query7 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Insomia = 1";
        String query8 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Menstrual_Problems = 1";
        String query9 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Backpain = 1";
        String query10 = "SELECT COUNT(*) AS total FROM patient_complaints WHERE Comp_Other IS NOT NULL";
        
        int Comp_Nausea = 0;
        int Comp_Difficulty_Breathing = 0;
        int Comp_Muscle_Cramps = 0;
        int Comp_Fatigue = 0;
        int Comp_Stomach_Problems = 0;
        int Comp_Blurry_Vision = 0;
        int Comp_Insomia = 0;
        int Comp_Menstrual_Problems = 0;
        int Comp_Backpain = 0;
        int Comp_Other = 0;
        
         try {
            Connection conn = DriverManager.getConnection(url, "root", sqlPass);
            Statement stmt = conn.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery(query1);
            if(rs.next()){ 
                Comp_Nausea = rs.getInt("total");
            }
            rs = stmt.executeQuery(query2);
            if(rs.next()){ 
                Comp_Difficulty_Breathing = rs.getInt("total");
            }
            rs = stmt.executeQuery(query3);
            if(rs.next()){ 
                Comp_Muscle_Cramps = rs.getInt("total");
            }
            rs = stmt.executeQuery(query4);
            if(rs.next()){ 
                Comp_Fatigue = rs.getInt("total");
            }
            rs = stmt.executeQuery(query5);
            if(rs.next()){ 
                Comp_Stomach_Problems = rs.getInt("total");
            }
            rs = stmt.executeQuery(query6);
            if(rs.next()){ 
                Comp_Blurry_Vision = rs.getInt("total");
            }
            rs = stmt.executeQuery(query7);
            if(rs.next()){ 
                Comp_Insomia = rs.getInt("total");
            }
            rs = stmt.executeQuery(query8);
            if(rs.next()){ 
                Comp_Menstrual_Problems = rs.getInt("total");
            }
            rs = stmt.executeQuery(query9);
            if(rs.next()){ 
                Comp_Backpain = rs.getInt("total");
            }
            rs = stmt.executeQuery(query10);
            if(rs.next()){ 
                Comp_Other = rs.getInt("total");
            }
            
            
            


            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();

        }   
        
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(Comp_Nausea, "Amount", "Nausea");
        dataset.setValue(Comp_Difficulty_Breathing, "Amount", "Difficulty Breathing");
        dataset.setValue(Comp_Muscle_Cramps, "Amount", "Muscle Cramps");
        dataset.setValue(Comp_Fatigue, "Amount", "Fatigue");
        dataset.setValue(Comp_Stomach_Problems, "Amount", "Stomach Problems");
        dataset.setValue(Comp_Blurry_Vision, "Amount", "Blurry Vision");
        dataset.setValue(Comp_Insomia, "Amount", "Insomia");
        dataset.setValue(Comp_Menstrual_Problems, "Amount", "Menstrual_Problems");
        dataset.setValue(Comp_Backpain, "Amount", "Backpain");
        dataset.setValue(Comp_Other, "Amount", "Other");

        JFreeChart chart = ChartFactory.createBarChart(
                "Complaint Graph", "Complaints", "Amount",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        CategoryPlot categoryPlot = chart.getCategoryPlot();
        categoryPlot.setBackgroundPaint(new Color(255, 255, 255));
        categoryPlot.setOutlineVisible(false);
        categoryPlot.setRangeGridlinePaint(Color.GRAY);
        categoryPlot.setDomainGridlinesVisible(true);
        categoryPlot.setDomainGridlinePaint(Color.LIGHT_GRAY);

        BarRenderer renderer = (BarRenderer) categoryPlot.getRenderer();
        GradientPaint gradient = new GradientPaint(0, 0, new Color(255, 101, 87), 0, 0, new Color(214, 61, 47));
        renderer.setSeriesPaint(0, gradient);  
        renderer.setDrawBarOutline(false);      
        renderer.setBarPainter(new StandardBarPainter()); 
        renderer.setShadowVisible(false);         
        renderer.setMaximumBarWidth(0.08);        

        chart.getTitle().setFont(new Font("SansSerif", Font.BOLD, 20));
        categoryPlot.getDomainAxis().setLabelFont(new Font("SansSerif", Font.BOLD, 14));
        categoryPlot.getRangeAxis().setLabelFont(new Font("SansSerif", Font.BOLD, 14));
        chart.getTitle().setPaint(new Color(50, 50, 50));

        ChartPanel barpChartPanel = new ChartPanel(chart);
        jPanel3.setLayout(new BorderLayout());
        jPanel3.removeAll();
        jPanel3.add(barpChartPanel, BorderLayout.CENTER);
        jPanel3.validate();
        jPanel3.repaint();
    }
  
    public void showPieChart() {
        
        String query1 = "SELECT COUNT(*) AS total FROM patient_records WHERE Patient_Type = 'STUDENT' ";
        String query2 = "SELECT COUNT(*) AS total FROM patient_records WHERE Patient_Type = 'TEACHER' ";
        String query3 = "SELECT COUNT(*) AS total FROM patient_records WHERE Patient_Type = \"SCHOOL STAFF\";";
        
        double student = 0;
        double teacher = 0;
        double school_staff = 0;
        
        try {
            Connection conn = DriverManager.getConnection(url, "root", sqlPass);
            Statement stmt = conn.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery(query1);
            if(rs.next()){ 
                student = rs.getDouble("total");
                
            }
            rs = stmt.executeQuery(query2);
            if(rs.next()){ 
                teacher = rs.getDouble("total");
            }
            rs = stmt.executeQuery(query3);
            if(rs.next()){ 
                school_staff = rs.getDouble("total");
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();

        }   
        
        
        double totalStudents = (double) (student/(student + teacher + school_staff)) * 100;
        double totalTeacher = (double) (teacher/(student + teacher + school_staff)) * 100;
        double totalSchoolStaff = (double) (school_staff/(student + teacher + school_staff)) * 100;
        
       
        
        // Create a dataset for the pie chart
        DefaultPieDataset pieDataset = new DefaultPieDataset();
        pieDataset.setValue( "STUDENT" , Double.valueOf(totalStudents) );
        pieDataset.setValue("TEACHER" , Double.valueOf( totalTeacher) );
        pieDataset.setValue("SCHOOL STAFF" , Double.valueOf( totalSchoolStaff) );

        // Create the pie chart
        JFreeChart pieChart = ChartFactory.createPieChart(
                "Patient Type Graph", // Chart title
                pieDataset,           // Dataset
                false,                // Include legend
                true,                 // Use tooltips
                false                 // Don't generate URLs
        );

        pieChart.getTitle().setFont(new Font("Arial", Font.BOLD, 18));
        pieChart.setBackgroundPaint(Color.decode("#FFFFFF"));

        PiePlot piePlot = (PiePlot) pieChart.getPlot();
        piePlot.setSectionPaint("STUDENT", new Color(255, 207, 207));
        piePlot.setSectionPaint("TEACHER", new Color(255, 125, 125)); 
        piePlot.setSectionPaint("SCHOOL STAFF", new Color(224, 17, 17));
        piePlot.setBackgroundPaint(Color.decode("#FFFFFF"));      
        piePlot.setOutlineVisible(false);       

        piePlot.setLabelFont(new Font("Arial", Font.PLAIN, 8));
        piePlot.setLabelPaint(Color.BLACK);
        piePlot.setLabelBackgroundPaint(Color.WHITE);

        ChartPanel chartPanel = new ChartPanel(pieChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 370));

        // Add the chart panel to the UI
        jPanel5.removeAll();
        jPanel5.add(chartPanel, BorderLayout.CENTER);
        jPanel5.validate();
    }
    
     public void showLineChart(){
        int[] monthlyCounts = new int[12];
        
        
          // SQL Query
        String sql = "SELECT EXTRACT(MONTH FROM Patient_Record_Date) AS month, COUNT(*) AS total_entries " +
                     "FROM patient_records " +
                     "GROUP BY EXTRACT(MONTH FROM Patient_Record_Date) " +
                     "ORDER BY month;";

        try (Connection conn = DriverManager.getConnection(url, "root", sqlPass);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int month = rs.getInt("month");
                int totalEntries = rs.getInt("total_entries");
                
                monthlyCounts[month - 1] = totalEntries;
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }   
        
         
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(monthlyCounts[0], "Amount", "jan");
        dataset.setValue(monthlyCounts[1], "Amount", "feb");
        dataset.setValue(monthlyCounts[2], "Amount", "mar");
        dataset.setValue(monthlyCounts[3], "Amount", "apr");
        dataset.setValue(monthlyCounts[4], "Amount", "may");
        dataset.setValue(monthlyCounts[5], "Amount", "jun");
        dataset.setValue(monthlyCounts[6], "Amount", "jul");
        dataset.setValue(monthlyCounts[7], "Amount", "aug");
        dataset.setValue(monthlyCounts[8], "Amount", "sep");
        dataset.setValue(monthlyCounts[9], "Amount", "oct");
        dataset.setValue(monthlyCounts[10], "Amount", "nov");
        dataset.setValue(monthlyCounts[11], "Amount", "dec");
        
        //create chart
        JFreeChart linechart = ChartFactory.createLineChart("Patients Monthly Graph","monthly","amount", 
                dataset, PlotOrientation.VERTICAL, false,true,false);
        
        //create plot object
         CategoryPlot lineCategoryPlot = linechart.getCategoryPlot();
       // lineCategoryPlot.setRangeGridlinePaint(Color.BLUE);
        lineCategoryPlot.setBackgroundPaint(Color.white);
        
        //create render object to change the moficy the line properties like color
         LineAndShapeRenderer lineRenderer = (LineAndShapeRenderer) lineCategoryPlot.getRenderer();
        Color lineChartColor = new Color(204,0,51);
        lineRenderer.setSeriesPaint(0, lineChartColor);
        
         //create chartPanel to display chart(graph)
        ChartPanel lineChartPanel = new ChartPanel(linechart);
        jPanel10.removeAll();
        jPanel10.add(lineChartPanel, BorderLayout.CENTER);
        jPanel10.validate();
    }
    
    
     public void loadPatientRecordsDataFromDatabase() {
        DefaultTableModel tblModel = (DefaultTableModel) patient_records_table.getModel();
        String userType = (String) patientTypeInput1.getSelectedItem();
        String sortBy = (String) sortInput.getSelectedItem();
        
        
        try {
            tblModel.setRowCount(0);
            Connection conn = DriverManager.getConnection( url, "root", sqlPass);
            
            
            ResultSet rs;
            
            
            if("Oldest to Latest".equals(sortBy)) {
                
                if("DIAGNOSED".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? ORDER BY Patient_Record_Date ASC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    } 
                } else if("UNDIAGNOSED".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? ORDER BY Patient_Record_Date ASC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    } 
                } else if(!"ALL".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Type = ? ORDER BY Patient_Record_Date ASC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    }  
                
                } else {
                    Statement stmt = conn.createStatement();
                    rs = stmt.executeQuery("SELECT * FROM patient_records ORDER BY Patient_Record_Date ASC");

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    }   
                }
            } else if("Latest to Oldest".equals(sortBy)) {
                if("DIAGNOSED".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? ORDER BY Patient_Record_Date DESC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    } 
                } else if("UNDIAGNOSED".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? ORDER BY Patient_Record_Date DESC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    } 
                } else if(!"ALL".equals(userType)) {
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Type = ? ORDER BY Patient_Record_Date DESC");
                    stmt.setString(1, userType);
                    rs = stmt.executeQuery();

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    }  
                
                } else {
                    Statement stmt = conn.createStatement();
                    rs = stmt.executeQuery("SELECT * FROM patient_records ORDER BY Patient_Record_Date DESC");

                    while (rs.next()) {
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                    } 
                }

            }
            
            
            

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
   
    public void loadUserDataFromDatabase() {
        DefaultTableModel tblModel = (DefaultTableModel) user_info_table.getModel();
        String userType = (String) patientTypeInput.getSelectedItem();
         
        try {
            tblModel.setRowCount(0);
            Connection conn = DriverManager.getConnection( url, "root", sqlPass);
            
            
            ResultSet rs;
            
            if(!"ALL".equals(userType)) {
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user_info WHERE User_Type = ?");
                stmt.setString(1, userType);
                rs = stmt.executeQuery();
               
                while (rs.next()) {
                    int id = rs.getInt("User_ID");
                    String name = rs.getString("User_Name");
                    String type = rs.getString("User_Type");
                    String strand_department = rs.getString("User_Strand_Department");
                    String position_section = rs.getString("User_Position_Section");
                    tblModel.addRow(new Object[]{id, name, type, strand_department, position_section});
                } 
                
            } else {
                Statement stmt = conn.createStatement();
                rs = stmt.executeQuery("SELECT * FROM user_info");
                
                while (rs.next()) {
                    int id = rs.getInt("User_ID");
                    String name = rs.getString("User_Name");
                    String type = rs.getString("User_Type");
                    String strand_department = rs.getString("User_Strand_Department");
                    String position_section = rs.getString("User_Position_Section");
                    tblModel.addRow(new Object[]{id, name, type, strand_department, position_section});
                } 
            }
            
            

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void loadAdminDataFromDatabase() {
        DefaultTableModel tblModel = (DefaultTableModel) admin_info_table.getModel();
         
        try {
            tblModel.setRowCount(0);
            Connection conn = DriverManager.getConnection( url, "root", sqlPass);
            
            
            ResultSet rs;
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM admin_info");

            while (rs.next()) {
                int id = rs.getInt("Admin_ID");
                String name = rs.getString("Admin_Name");
                String position = rs.getString("Admin_Position");
                
                tblModel.addRow(new Object[]{id, name, position});
            } 
            
            

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    void stylePatientRecordsTable(){
        
        JTable table = patient_records_table;
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                        boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    
                    if (row % 2 == 0) {
                        c.setBackground(new java.awt.Color(255, 119, 122));
                        c.setForeground(Color.white);
                    } else {
                        c.setBackground(Color.WHITE);
                        c.setForeground(Color.black);
                    }
                    
                    if (isSelected) {
                        c.setBackground(new java.awt.Color(142, 40, 42));
                        c.setForeground(Color.white);
                    }
                    return c;
                }
            });

            table.setRowHeight(30);
            table.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));

            TableColumnModel columnModel = table.getColumnModel();
            columnModel.getColumn(0).setPreferredWidth(15);
            columnModel.getColumn(1).setPreferredWidth(69);
            columnModel.getColumn(2).setPreferredWidth(69); 
            columnModel.getColumn(3).setPreferredWidth(69); 
            columnModel.getColumn(4).setPreferredWidth(69); 
            columnModel.getColumn(5).setPreferredWidth(69);

            table.getTableHeader().setBackground(new java.awt.Color(146, 26, 28));
            table.getTableHeader().setForeground(Color.WHITE);
            table.getTableHeader().setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));

    }
    
    
    void styleUserTable(){
        
        JTable table = user_info_table;
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                        boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    
                    if (row % 2 == 0) {
                        c.setBackground(new java.awt.Color(255, 119, 122));
                        c.setForeground(Color.white);
                    } else {
                        c.setBackground(Color.WHITE);
                        c.setForeground(Color.black);
                    }
                    
                    if (isSelected) {
                        c.setBackground(new java.awt.Color(142, 40, 42));
                        c.setForeground(Color.white);
                    }
                    return c;
                }
            });

            table.setRowHeight(30);
            table.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));

            TableColumnModel columnModel = table.getColumnModel();
            columnModel.getColumn(0).setPreferredWidth(50);
            columnModel.getColumn(1).setPreferredWidth(75);
            columnModel.getColumn(2).setPreferredWidth(30); 
            columnModel.getColumn(3).setPreferredWidth(145); 
            columnModel.getColumn(4).setPreferredWidth(75); 

            table.getTableHeader().setBackground(new java.awt.Color(146, 26, 28));
            table.getTableHeader().setForeground(Color.WHITE);
            table.getTableHeader().setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));

    }
    
    void styleAdminTable(){
        
        JTable table = admin_info_table;
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                        boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    
                    if (row % 2 == 0) {
                        c.setBackground(new java.awt.Color(255, 119, 122));
                        c.setForeground(Color.white);
                    } else {
                        c.setBackground(Color.WHITE);
                        c.setForeground(Color.black);
                    }
                    
                    if (isSelected) {
                        c.setBackground(new java.awt.Color(142, 40, 42));
                        c.setForeground(Color.white);
                    }
                    return c;
                }
            });

            table.setRowHeight(30);
            table.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 12));

            TableColumnModel columnModel = table.getColumnModel();
            columnModel.getColumn(0).setPreferredWidth(60);
            columnModel.getColumn(1).setPreferredWidth(115);
            columnModel.getColumn(2).setPreferredWidth(50); 

            table.getTableHeader().setBackground(new java.awt.Color(146, 26, 28));
            table.getTableHeader().setForeground(Color.WHITE);
            table.getTableHeader().setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 12));

    }
    
    
    
    ImageIcon setImage(String url, JLabel label) {

        ImageIcon img1 = new ImageIcon(url);
        Image img2 = img1.getImage();
        int hei = label.getHeight();
        int wid = label.getWidth();
        Image img3 = img2.getScaledInstance(wid, hei, wid);

        ImageIcon finalimg = new ImageIcon(img3);
        return finalimg;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        logo_label = new javax.swing.JLabel();
        minimize_label = new javax.swing.JLabel();
        close_label = new javax.swing.JLabel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        dashboardBtn = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        patientRecordsBtn = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        userRecordsBtn = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        adminRecordsBtn = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        clinic_logo = new javax.swing.JLabel();
        mainContentPanel = new javax.swing.JPanel();
        dashboard = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        patient_records = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        patient_records_table = new javax.swing.JTable();
        patientTypeInput1 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        sortInput = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        searchIDInput1 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        startDateChooser = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        endDateChooser = new com.toedter.calendar.JDateChooser();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        jButton16 = new javax.swing.JButton();
        selectedID1 = new javax.swing.JLabel();
        user_records = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        searchIDInput = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        patientTypeInput = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        selectedID = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        user_info_table = new javax.swing.JTable();
        admin_records = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        admin_info_table = new javax.swing.JTable();
        jLabel32 = new javax.swing.JLabel();
        adminIDInput = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        adminNameInput = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        adminPositionInput = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        adminPasswordInput = new javax.swing.JPasswordField();
        viewPassword = new javax.swing.JLabel();
        viewPassword1 = new javax.swing.JLabel();
        currentPasswordInput = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(175, 82, 82));
        jLabel2.setText("ALLSHS CLINIC RECORDING SYSTEM");
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 452, -1));

        logo_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/allshs_logo.jpg"))); // NOI18N
        logo_label.setText("jLabel6");
        jPanel7.add(logo_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 55, 55));

        minimize_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/minimize_icon.png"))); // NOI18N
        minimize_label.setText("jLabel6");
        minimize_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimize_labelminimize_form(evt);
            }
        });
        jPanel7.add(minimize_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 20, 25, 25));

        close_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close_icon.png"))); // NOI18N
        close_label.setText("jLabel6");
        close_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close_labelclose_form(evt);
            }
        });
        jPanel7.add(close_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 20, 25, 25));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 70));

        jSplitPane1.setDividerSize(0);

        jPanel1.setBackground(new java.awt.Color(223, 110, 110));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboardBtn.setBackground(new java.awt.Color(223, 110, 110));
        dashboardBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                dashboardBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                dashboardBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboardBtnMousePressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("DASHBOARD");

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/dashboard_icon.png"))); // NOI18N
        jLabel8.setText("jLabel8");

        javax.swing.GroupLayout dashboardBtnLayout = new javax.swing.GroupLayout(dashboardBtn);
        dashboardBtn.setLayout(dashboardBtnLayout);
        dashboardBtnLayout.setHorizontalGroup(
            dashboardBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboardBtnLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        dashboardBtnLayout.setVerticalGroup(
            dashboardBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboardBtnLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(dashboardBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        jPanel1.add(dashboardBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 200, 60));

        patientRecordsBtn.setBackground(new java.awt.Color(223, 110, 110));
        patientRecordsBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                patientRecordsBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                patientRecordsBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                patientRecordsBtnMousePressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("PATIENT RECORDS");

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/patient_icon.png"))); // NOI18N
        jLabel14.setText("jLabel8");

        javax.swing.GroupLayout patientRecordsBtnLayout = new javax.swing.GroupLayout(patientRecordsBtn);
        patientRecordsBtn.setLayout(patientRecordsBtnLayout);
        patientRecordsBtnLayout.setHorizontalGroup(
            patientRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, patientRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        patientRecordsBtnLayout.setVerticalGroup(
            patientRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, patientRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(patientRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        jPanel1.add(patientRecordsBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 200, 60));

        userRecordsBtn.setBackground(new java.awt.Color(223, 110, 110));
        userRecordsBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                userRecordsBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                userRecordsBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                userRecordsBtnMousePressed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("USER RECORDS");

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/user_icon.png"))); // NOI18N
        jLabel16.setText("jLabel8");

        javax.swing.GroupLayout userRecordsBtnLayout = new javax.swing.GroupLayout(userRecordsBtn);
        userRecordsBtn.setLayout(userRecordsBtnLayout);
        userRecordsBtnLayout.setHorizontalGroup(
            userRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, userRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        userRecordsBtnLayout.setVerticalGroup(
            userRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, userRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(userRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        jPanel1.add(userRecordsBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 200, 60));

        adminRecordsBtn.setBackground(new java.awt.Color(223, 110, 110));
        adminRecordsBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                adminRecordsBtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                adminRecordsBtnMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                adminRecordsBtnMousePressed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("ADMIN RECORDS");
        jLabel17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/admin_icon.png"))); // NOI18N
        jLabel18.setText("jLabel8");

        javax.swing.GroupLayout adminRecordsBtnLayout = new javax.swing.GroupLayout(adminRecordsBtn);
        adminRecordsBtn.setLayout(adminRecordsBtnLayout);
        adminRecordsBtnLayout.setHorizontalGroup(
            adminRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        adminRecordsBtnLayout.setVerticalGroup(
            adminRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adminRecordsBtnLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(adminRecordsBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15))
        );

        jPanel1.add(adminRecordsBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 200, 60));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("ADMIN");
        jPanel1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, -1, -1));

        clinic_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clinic_logo.png"))); // NOI18N
        clinic_logo.setText("jLabel1");
        jPanel1.add(clinic_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 150, 150));

        jSplitPane1.setLeftComponent(jPanel1);

        mainContentPanel.setBackground(new java.awt.Color(197, 70, 70));
        mainContentPanel.setLayout(new java.awt.CardLayout());

        dashboard.setBackground(new java.awt.Color(197, 70, 70));
        dashboard.setName("dashboard"); // NOI18N
        dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel10.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 664, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        dashboard.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 60, 700, 280));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel3.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 994, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        dashboard.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 1030, 280));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("DASHBOARD");
        dashboard.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 15, 260, -1));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        dashboard.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 320, 280));

        mainContentPanel.add(dashboard, "dashboard");

        patient_records.setBackground(new java.awt.Color(197, 70, 70));
        patient_records.setName("patient_records"); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("PATIENT RECORDS");

        patient_records_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "RECORD ID", "PATIENT ID", "NAME", "TYPE", "STATUS", "DATE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        patient_records_table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        patient_records_table.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(patient_records_table);

        patientTypeInput1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "STUDENT", "TEACHER", "SCHOOL STAFF", "UNDIAGNOSED", "DIAGNOSED" }));
        patientTypeInput1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        patientTypeInput1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientTypeInput1ActionPerformed(evt);
            }
        });

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Patient Type:");

        sortInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Oldest to Latest", "Latest to Oldest" }));
        sortInput.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        sortInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sortInputActionPerformed(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Sort by:");

        jButton4.setBackground(new java.awt.Color(141, 31, 31));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("SEARCH");
        jButton4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Enter Patient ID:");

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Show records between dates:");

        jButton5.setBackground(new java.awt.Color(141, 31, 31));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("VIEW PATIENT RECORD");
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(141, 31, 31));
        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("RESET");
        jButton6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(141, 31, 31));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("PRINT");
        jButton7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel39.setBackground(new java.awt.Color(255, 255, 255));
        jLabel39.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Selected Record ID:");

        jButton16.setBackground(new java.awt.Color(141, 31, 31));
        jButton16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton16.setForeground(new java.awt.Color(255, 255, 255));
        jButton16.setText("VIEW DATES");
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        selectedID1.setBackground(new java.awt.Color(255, 255, 255));
        selectedID1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        selectedID1.setForeground(new java.awt.Color(255, 255, 255));
        selectedID1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout patient_recordsLayout = new javax.swing.GroupLayout(patient_records);
        patient_records.setLayout(patient_recordsLayout);
        patient_recordsLayout.setHorizontalGroup(
            patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, patient_recordsLayout.createSequentialGroup()
                .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addGap(456, 456, 456)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE))
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(selectedID1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(89, 89, 89)))
                .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(115, 115, 115)
                        .addComponent(jLabel10))
                    .addComponent(jLabel12)
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addComponent(searchIDInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(73, 73, 73))
            .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(patient_recordsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 1049, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel13)
                        .addGroup(patient_recordsLayout.createSequentialGroup()
                            .addComponent(startDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(6, 6, 6)
                            .addComponent(endDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(275, 275, 275)
                            .addComponent(sortInput, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(12, 12, 12)
                            .addComponent(patientTypeInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(patient_recordsLayout.createSequentialGroup()
                            .addGap(1, 1, 1)
                            .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1038, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(patient_recordsLayout.createSequentialGroup()
                            .addGap(886, 886, 886)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        patient_recordsLayout.setVerticalGroup(
            patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(patient_recordsLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel10))
                .addGap(3, 3, 3)
                .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(patient_recordsLayout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(searchIDInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(patient_recordsLayout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(patient_recordsLayout.createSequentialGroup()
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(selectedID1, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(483, Short.MAX_VALUE))
            .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(patient_recordsLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel6)
                    .addGap(6, 6, 6)
                    .addComponent(jLabel13)
                    .addGap(6, 6, 6)
                    .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(startDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(endDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(sortInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(patientTypeInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(26, 26, 26)
                    .addGroup(patient_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(21, 21, 21)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainContentPanel.add(patient_records, "patient_records");

        user_records.setBackground(new java.awt.Color(197, 70, 70));
        user_records.setName("user_records"); // NOI18N

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("USER RECORDS");

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Enter User ID:");

        jButton8.setBackground(new java.awt.Color(141, 31, 31));
        jButton8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("SEARCH");
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        patientTypeInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "STUDENT", "TEACHER", "SCHOOL STAFF" }));
        patientTypeInput.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        patientTypeInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patientTypeInputActionPerformed(evt);
            }
        });

        jLabel29.setBackground(new java.awt.Color(255, 255, 255));
        jLabel29.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Patient Type:");

        jButton9.setBackground(new java.awt.Color(141, 31, 31));
        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("ADD USER");
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(141, 31, 31));
        jButton10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("DELETE USER");
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(141, 31, 31));
        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("EDIT USER");
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel31.setBackground(new java.awt.Color(255, 255, 255));
        jLabel31.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Selected User ID:");

        selectedID.setBackground(new java.awt.Color(255, 255, 255));
        selectedID.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        selectedID.setForeground(new java.awt.Color(255, 255, 255));

        user_info_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "TYPE", "STRAND AND DEPARTMENT", "POSITION AND SECTION"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        user_info_table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        user_info_table.setRowHeight(40);
        user_info_table.setSelectionBackground(new java.awt.Color(197, 53, 53));
        user_info_table.getTableHeader().setReorderingAllowed(false);
        jScrollPane4.setViewportView(user_info_table);

        javax.swing.GroupLayout user_recordsLayout = new javax.swing.GroupLayout(user_records);
        user_records.setLayout(user_recordsLayout);
        user_recordsLayout.setHorizontalGroup(
            user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(user_recordsLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, 1056, Short.MAX_VALUE)
                    .addGroup(user_recordsLayout.createSequentialGroup()
                        .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(user_recordsLayout.createSequentialGroup()
                                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(patientTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel29))
                                .addGap(18, 18, 18)
                                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel25)
                                    .addGroup(user_recordsLayout.createSequentialGroup()
                                        .addComponent(searchIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(user_recordsLayout.createSequentialGroup()
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 871, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(user_recordsLayout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel31)
                                    .addComponent(selectedID, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 10, Short.MAX_VALUE)))
                .addContainerGap())
        );
        user_recordsLayout.setVerticalGroup(
            user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, user_recordsLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel30)
                .addGap(18, 18, 18)
                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jLabel29))
                .addGap(1, 1, 1)
                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(patientTypeInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(user_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(user_recordsLayout.createSequentialGroup()
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(selectedID))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        mainContentPanel.add(user_records, "user_records");

        admin_records.setBackground(new java.awt.Color(197, 70, 70));
        admin_records.setName("admin_records"); // NOI18N

        admin_info_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "POSITION"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        admin_info_table.setRowHeight(40);
        admin_info_table.setSelectionBackground(new java.awt.Color(197, 53, 53));
        admin_info_table.getTableHeader().setReorderingAllowed(false);
        jScrollPane5.setViewportView(admin_info_table);

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("ADMIN RECORDS");

        adminIDInput.setOpaque(true);

        jLabel33.setBackground(new java.awt.Color(255, 255, 255));
        jLabel33.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Employee ID:");

        jLabel34.setBackground(new java.awt.Color(255, 255, 255));
        jLabel34.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Name:");

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("ADMIN PROFILE");

        jLabel36.setBackground(new java.awt.Color(255, 255, 255));
        jLabel36.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Position:");

        jButton12.setBackground(new java.awt.Color(141, 31, 31));
        jButton12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("DELETE");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setBackground(new java.awt.Color(141, 31, 31));
        jButton13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setText("ADD ");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setBackground(new java.awt.Color(141, 31, 31));
        jButton14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setText("CHANGE PASSWORD");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setBackground(new java.awt.Color(141, 31, 31));
        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setText("EDIT");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jLabel37.setBackground(new java.awt.Color(255, 255, 255));
        jLabel37.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Password:");

        jLabel38.setBackground(new java.awt.Color(255, 255, 255));
        jLabel38.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Enter Current Password to Change Password:");

        viewPassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/view_icon.png"))); // NOI18N
        viewPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewPasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewPasswordMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewPasswordMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                viewPasswordMouseReleased(evt);
            }
        });

        viewPassword1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/view_icon.png"))); // NOI18N
        viewPassword1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                viewPassword1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                viewPassword1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewPassword1MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                viewPassword1MouseReleased(evt);
            }
        });

        javax.swing.GroupLayout admin_recordsLayout = new javax.swing.GroupLayout(admin_records);
        admin_records.setLayout(admin_recordsLayout);
        admin_recordsLayout.setHorizontalGroup(
            admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_recordsLayout.createSequentialGroup()
                .addGap(0, 45, Short.MAX_VALUE)
                .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(admin_recordsLayout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(admin_recordsLayout.createSequentialGroup()
                                .addGap(110, 110, 110)
                                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel33)
                            .addComponent(adminIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel34)
                            .addComponent(adminNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel36)
                            .addComponent(adminPositionInput, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel37)
                            .addGroup(admin_recordsLayout.createSequentialGroup()
                                .addComponent(adminPasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(viewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(admin_recordsLayout.createSequentialGroup()
                                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel38)
                            .addGroup(admin_recordsLayout.createSequentialGroup()
                                .addComponent(currentPasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(viewPassword1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 45, Short.MAX_VALUE))
        );
        admin_recordsLayout.setVerticalGroup(
            admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(admin_recordsLayout.createSequentialGroup()
                .addGap(0, 35, Short.MAX_VALUE)
                .addComponent(jLabel32)
                .addGap(8, 8, 8)
                .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(admin_recordsLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(admin_recordsLayout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel33)
                        .addGap(0, 0, 0)
                        .addComponent(adminIDInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel34)
                        .addGap(0, 0, 0)
                        .addComponent(adminNameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel36)
                        .addGap(0, 0, 0)
                        .addComponent(adminPositionInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(jLabel37)
                        .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminPasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(viewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(40, 40, 40)
                        .addComponent(jLabel38)
                        .addGroup(admin_recordsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(currentPasswordInput, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(viewPassword1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 35, Short.MAX_VALUE))
        );

        mainContentPanel.add(admin_records, "admin_records");

        jSplitPane1.setRightComponent(mainContentPanel);

        getContentPane().add(jSplitPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1280, 660));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void minimize_labelminimize_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelminimize_form
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimize_labelminimize_form

    private void close_labelclose_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelclose_form
        new login_form().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_close_labelclose_form

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        if ("".equals(adminIDInput.getText())) {
            JOptionPane.showMessageDialog(null, "Select Admin ID to Delete!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM admin_info WHERE Admin_ID = ?;");
                stmt.setInt(1, Integer.parseInt(adminIDInput.getText()));
                ResultSet rs = stmt.executeQuery();
                int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete admin: " + adminIDInput.getText() + " from database?", "Delete Admin", JOptionPane.YES_NO_OPTION);
                if(rs.next() && input == 0) {

                    stmt = conn.prepareStatement("DELETE FROM admin_info WHERE Admin_ID = ?;");
                    stmt.setInt(1, Integer.parseInt(adminIDInput.getText()));

                    int rowsRemoved = stmt.executeUpdate();
                    adminIDInput.setText("");
                    adminNameInput.setText("");
                    adminPositionInput.setText("");
                    JOptionPane.showMessageDialog(this, "Admin Deleted successfully!");
                } else if(!rs.next()) {
                    JOptionPane.showMessageDialog(null, "ID: "+ adminIDInput.getText() + " is not in the admin database!", "Error", JOptionPane.ERROR_MESSAGE);
                }

                stmt.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            }
        }

        loadAdminDataFromDatabase();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        char[] passwordInputChars = adminPasswordInput.getPassword();
        String passwordInput = new String(passwordInputChars);

        if ("".equals(adminIDInput.getText()) || "".equals(adminNameInput.getText()) || "".equals(adminPositionInput.getText()) || "".equals(passwordInput)) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit admin details?", "Submit Admin Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {
                try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                    String sql = "INSERT INTO admin_info (Admin_ID, Admin_Name, Admin_Position, Admin_Password) VALUES (?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, Integer.parseInt(adminIDInput.getText()));
                    stmt.setString(2, adminNameInput.getText());
                    stmt.setString(3, adminPositionInput.getText());
                    stmt.setString(4, passwordInput);

                    stmt.executeUpdate();

                    stmt.close();
                    conn.close();

                    loadAdminDataFromDatabase();
                    JOptionPane.showMessageDialog(this, "User added successfully!");

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                }

            }
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        char[] newPasswordChars = adminPasswordInput.getPassword();
        String newPassword = new String(newPasswordChars);
        char[] currentPasswordChars = currentPasswordInput.getPassword();
        String currentPassword = new String(currentPasswordChars);

        if("".equals(currentPassword) || "".equals(newPassword)) {
            JOptionPane.showMessageDialog(null, "Fill in all password fields to change password!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            try {
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM admin_info WHERE Admin_ID = ?;");
                stmt.setInt(1, Integer.parseInt(adminIDInput.getText()));
                ResultSet rs = stmt.executeQuery();
                int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to change your password: " + adminIDInput.getText() + " from database?", "Delete Admin", JOptionPane.YES_NO_OPTION);

                if(rs.next() && input == 0) {
                    if (currentPassword.equals(rs.getString("Admin_Password"))) {
                        stmt = conn.prepareStatement("UPDATE admin_info SET Admin_Password = ? WHERE Admin_ID = ?;");
                        stmt.setString(1, newPassword);
                        stmt.setInt(2, Integer.parseInt(adminIDInput.getText()));

                        stmt.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Password changed successfully!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Currnt Password Incorrect!", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } else if(!rs.next()) {
                    JOptionPane.showMessageDialog(null, "ID: "+ adminIDInput.getText() + " is not in the admin database!", "Error", JOptionPane.ERROR_MESSAGE);
                }

                stmt.close();
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
            }

        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        if ("".equals(adminIDInput.getText()) || "".equals(adminNameInput.getText()) || "".equals(adminPositionInput.getText())) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit edit details?", "Edit User Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {
                try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                    String sql = "UPDATE admin_info SET Admin_ID = ?, Admin_Name = ?,  Admin_Position = ? WHERE Admin_ID = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, Integer.parseInt(adminIDInput.getText()));
                    stmt.setString(2, adminNameInput.getText());
                    stmt.setString(3, adminPositionInput.getText());
                    stmt.setInt(4, Integer.parseInt(adminIDInput.getText()));

                    stmt.executeUpdate();

                    stmt.close();
                    conn.close();

                    loadAdminDataFromDatabase();

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                }
                JOptionPane.showConfirmDialog(null, "Data edited successfully!", "Edit Successful", JOptionPane.DEFAULT_OPTION);

            }
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void viewPasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPasswordMouseEntered
        viewPassword.setIcon(setImage("src/images/view_icon1.png", viewPassword));
    }//GEN-LAST:event_viewPasswordMouseEntered

    private void viewPasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPasswordMouseExited
        viewPassword.setIcon(setImage("src/images/view_icon.png", viewPassword));
    }//GEN-LAST:event_viewPasswordMouseExited

    private void viewPasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPasswordMousePressed
        adminPasswordInput.setEchoChar((char) 0);
    }//GEN-LAST:event_viewPasswordMousePressed

    private void viewPasswordMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPasswordMouseReleased
        adminPasswordInput.setEchoChar('•');
    }//GEN-LAST:event_viewPasswordMouseReleased

    private void viewPassword1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPassword1MouseEntered
        viewPassword1.setIcon(setImage("src/images/view_icon1.png", viewPassword1));
    }//GEN-LAST:event_viewPassword1MouseEntered

    private void viewPassword1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPassword1MouseExited
        viewPassword1.setIcon(setImage("src/images/view_icon.png", viewPassword1));
    }//GEN-LAST:event_viewPassword1MouseExited

    private void viewPassword1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPassword1MousePressed
        currentPasswordInput.setEchoChar((char) 0);
    }//GEN-LAST:event_viewPassword1MousePressed

    private void viewPassword1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewPassword1MouseReleased
        currentPasswordInput.setEchoChar('•');
    }//GEN-LAST:event_viewPassword1MouseReleased

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        DefaultTableModel tblModel = (DefaultTableModel) user_info_table.getModel();
        String ID = searchIDInput.getText();
        String userType = (String) patientTypeInput.getSelectedItem();

        if("ALL".equals(userType)) {
            try {
                tblModel.setRowCount(0);
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user_info WHERE User_ID = ?");
                stmt.setString(1, ID);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int id = rs.getInt("User_ID");
                    String name = rs.getString("User_Name");
                    String type = rs.getString("User_Type");
                    String strand_department = rs.getString("User_Strand_Department");
                    String position_section = rs.getString("User_Position_Section");
                    tblModel.addRow(new Object[]{id, name, type, strand_department, position_section});
                } else {
                    JOptionPane.showMessageDialog(null, "User does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                    loadUserDataFromDatabase();
                }

                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        } else {
            try {
                tblModel.setRowCount(0);
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user_info WHERE User_ID = ? AND User_Type = ?");
                stmt.setString(1, ID);
                stmt.setString(2, userType);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    int id = rs.getInt("User_ID");
                    String name = rs.getString("User_Name");
                    String type = rs.getString("User_Type");
                    String strand_department = rs.getString("User_Strand_Department");
                    String position_section = rs.getString("User_Position_Section");
                    tblModel.addRow(new Object[]{id, name, type, strand_department, position_section});
                } else {
                    JOptionPane.showMessageDialog(null, "User does not exist!", "Error", JOptionPane.ERROR_MESSAGE);
                    loadUserDataFromDatabase();
                }

                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        }

    }//GEN-LAST:event_jButton8ActionPerformed

    private void patientTypeInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientTypeInputActionPerformed
        loadUserDataFromDatabase();
    }//GEN-LAST:event_patientTypeInputActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        new add_user_form(this).setVisible(true);

    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed

        if(!"".equals(this.selectedID.getText())){
            String selectedID = this.selectedID.getText();

            int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete user: " + selectedID + " from database?", "Delete User", JOptionPane.YES_NO_OPTION);
            if(input == 0) {

                try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                    String sql = "DELETE FROM user_info WHERE User_ID = " + selectedID;
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    int rowsRemoved = stmt.executeUpdate();

                    stmt.close();
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
                }
                JOptionPane.showConfirmDialog(null, "User: " + selectedID + " deleted from database!", "Deletion Successful", JOptionPane.DEFAULT_OPTION);
                this.selectedID.setText("");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Select User to Delete!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        loadUserDataFromDatabase();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        edit_user_form editForm;

        if(!"".equals(selectedID.getText())){
            switch (selectedUserType) {
                case "STUDENT":
                editForm = new edit_user_form(this, 0, selectedUserID, selectedUserName, selectedUserType, selectedUserStrandDepartment, selectedUserPositionSection);
                editForm.setVisible(true);
                break;
                case "TEACHER":
                editForm = new edit_user_form(this, 1, selectedUserID, selectedUserName, selectedUserType, selectedUserStrandDepartment, selectedUserPositionSection);
                editForm.setVisible(true);
                break;
                case "SCHOOL STAFF":
                editForm = new edit_user_form(this, 2, selectedUserID, selectedUserName, selectedUserType, selectedUserStrandDepartment, selectedUserPositionSection);
                editForm.setVisible(true);
                break;

            }
        } else {
            JOptionPane.showMessageDialog(null, "Select User to Edit!", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton11ActionPerformed

    private void patientTypeInput1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patientTypeInput1ActionPerformed
        loadPatientRecordsDataFromDatabase();
    }//GEN-LAST:event_patientTypeInput1ActionPerformed

    private void sortInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortInputActionPerformed
        loadPatientRecordsDataFromDatabase();
    }//GEN-LAST:event_sortInputActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        DefaultTableModel tblModel = (DefaultTableModel) patient_records_table.getModel();
        String ID = searchIDInput1.getText();
        String userType = (String) patientTypeInput1.getSelectedItem();

        if("DIAGNOSED".equals(userType) || "UNDIAGNOSED".equals(userType)) {

            try {
                tblModel.setRowCount(0);
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_ID = ? AND Patient_Record_Status = ?");
                stmt.setString(1, ID);
                stmt.setString(2, userType);
                ResultSet rs = stmt.executeQuery();

               
                    while(rs.next()){
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                
                    }
                    
                
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        } else if("ALL".equals(userType)) {
            try {
                tblModel.setRowCount(0);
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_ID = ?");
                stmt.setString(1, ID);
                ResultSet rs = stmt.executeQuery();

                
                    while(rs.next()){
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                
                    }
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        } else {
            try {
                tblModel.setRowCount(0);
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_ID = ? AND Patient_Type = ?");
                stmt.setString(1, ID);
                stmt.setString(2, userType);
                ResultSet rs = stmt.executeQuery();

                
                    while(rs.next()){
                        int recordID = rs.getInt("Patient_Record_ID");
                        int id = rs.getInt("Patient_ID");
                        String name = rs.getString("Patient_Name");
                        String type = rs.getString("Patient_Type");
                        String record_status = rs.getString("Patient_Record_Status");
                        String record_date= rs.getString("Patient_Record_Date");
                        tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                
                    }
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        try {
            Connection conn = DriverManager.getConnection(url, "root", sqlPass);
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_ID = ?");
            stmt.setString(1, selectedID1.getText());
            ResultSet rs = stmt.executeQuery();

            if(rs.next()) {
                int recordID = rs.getInt("Patient_Record_ID");
                int ID = rs.getInt("Patient_ID");
                String type = rs.getString("Patient_Type");
                String name = rs.getString("Patient_Name");
                int age = rs.getInt("Patient_Age");
                String sex = rs.getString("Patient_Sex");
                String strandDepartment = rs.getString("Patient_Strand_Department");
                String positionSection = rs.getString("Patient_Position_Section");
                String recordDate = rs.getDate("Patient_Record_Date").toString();
                String patientStatus = rs.getString("Patient_Record_Status");
                new patient_details_form(recordID,ID, type, name, age, sex, strandDepartment, positionSection, recordDate, patientStatus).setVisible(true);

            } else {
                System.out.println("h");
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();

        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        startDateChooser.setDate(null);
        endDateChooser.setDate(null);
        loadPatientRecordsDataFromDatabase();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        printToPDF.exportTableToPDF(patient_records_table,  "C:\\Users\\basba\\Desktop\\Patient_Records_Report_" + LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy"))+".pdf");
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed

        String userType = (String) patientTypeInput1.getSelectedItem();
        DefaultTableModel tblModel = (DefaultTableModel) patient_records_table.getModel();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startDate = sdf.format(startDateChooser.getDate());
        String endDate = sdf.format(endDateChooser.getDate());

        // Clear previous data
        tblModel.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection(url, "root", sqlPass);
            PreparedStatement pstmt;

            if("UNDIAGNOSED".equals(userType)) {
                pstmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? AND Patient_Record_Date BETWEEN ? AND ? ORDER BY Patient_Record_Date ASC");
                pstmt.setString(1, userType);
                pstmt.setString(2, startDate);
                pstmt.setString(3, endDate);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    int recordID = rs.getInt("Patient_Record_ID");
                    int id = rs.getInt("Patient_ID");
                    String name = rs.getString("Patient_Name");
                    String type = rs.getString("Patient_Type");
                    String record_status = rs.getString("Patient_Record_Status");
                    String record_date= rs.getString("Patient_Record_Date");
                    tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                }
            } else if("DIAGNOSED".equals(userType)) {
                pstmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Status = ? AND Patient_Record_Date BETWEEN ? AND ? ORDER BY Patient_Record_Date ASC");
                pstmt.setString(1, userType);
                pstmt.setString(2, startDate);
                pstmt.setString(3, endDate);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    int recordID = rs.getInt("Patient_Record_ID");
                    int id = rs.getInt("Patient_ID");
                    String name = rs.getString("Patient_Name");
                    String type = rs.getString("Patient_Type");
                    String record_status = rs.getString("Patient_Record_Status");
                    String record_date= rs.getString("Patient_Record_Date");
                    tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                }
            } else if(!"ALL".equals(userType)) {
                pstmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Type = ? AND Patient_Record_Date BETWEEN ? AND ? ORDER BY Patient_Record_Date ASC");
                pstmt.setString(1, userType);
                pstmt.setString(2, startDate);
                pstmt.setString(3, endDate);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    int recordID = rs.getInt("Patient_Record_ID");
                    int id = rs.getInt("Patient_ID");
                    String name = rs.getString("Patient_Name");
                    String type = rs.getString("Patient_Type");
                    String record_status = rs.getString("Patient_Record_Status");
                    String record_date= rs.getString("Patient_Record_Date");
                    tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                }
            } else {
                pstmt = conn.prepareStatement("SELECT * FROM patient_records WHERE Patient_Record_Date BETWEEN ? AND ? ORDER BY Patient_Record_Date ASC");
                pstmt.setString(1, startDate);
                pstmt.setString(2, endDate);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    int recordID = rs.getInt("Patient_Record_ID");
                    int id = rs.getInt("Patient_ID");
                    String name = rs.getString("Patient_Name");
                    String type = rs.getString("Patient_Type");
                    String record_status = rs.getString("Patient_Record_Status");
                    String record_date= rs.getString("Patient_Record_Date");
                    tblModel.addRow(new Object[]{recordID, id, name, type, record_status, record_date});
                }
            }

            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Error!", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton16ActionPerformed

    private void dashboardBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardBtnMousePressed
        CardLayout cardLayout = (CardLayout) mainContentPanel.getLayout();
        cardLayout.show(mainContentPanel, "dashboard");
    }//GEN-LAST:event_dashboardBtnMousePressed

    private void patientRecordsBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientRecordsBtnMousePressed
        CardLayout cardLayout = (CardLayout) mainContentPanel.getLayout();
        cardLayout.show(mainContentPanel, "patient_records");
    }//GEN-LAST:event_patientRecordsBtnMousePressed

    private void userRecordsBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userRecordsBtnMousePressed
        CardLayout cardLayout = (CardLayout) mainContentPanel.getLayout();
        cardLayout.show(mainContentPanel, "user_records");
    }//GEN-LAST:event_userRecordsBtnMousePressed

    private void adminRecordsBtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminRecordsBtnMousePressed
        CardLayout cardLayout = (CardLayout) mainContentPanel.getLayout();
        cardLayout.show(mainContentPanel, "admin_records");
       
    }//GEN-LAST:event_adminRecordsBtnMousePressed

    private void dashboardBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardBtnMouseEntered
        dashboardBtn.setBackground(new Color(190,54,56));
        jLabel3.setForeground(new Color(255,192,210));
        jLabel8.setIcon(setImage("src/images/dashboard_icon_Hover.png", jLabel8));
    }//GEN-LAST:event_dashboardBtnMouseEntered

    private void dashboardBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardBtnMouseExited
        dashboardBtn.setBackground(new Color(223,110,110));
        jLabel3.setForeground(new Color(255,255,255));
        jLabel8.setIcon(setImage("src/images/dashboard_icon.png", jLabel8));
    }//GEN-LAST:event_dashboardBtnMouseExited

    private void patientRecordsBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientRecordsBtnMouseEntered
        patientRecordsBtn.setBackground(new Color(190,54,56));
        jLabel9.setForeground(new Color(255,192,210));
        jLabel14.setIcon(setImage("src/images/patient_icon_Hover.png", jLabel14));
    }//GEN-LAST:event_patientRecordsBtnMouseEntered

    private void patientRecordsBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_patientRecordsBtnMouseExited
        patientRecordsBtn.setBackground(new Color(223,110,110));
        jLabel9.setForeground(new Color(255,255,255));
        jLabel14.setIcon(setImage("src/images/patient_icon.png", jLabel14));
    }//GEN-LAST:event_patientRecordsBtnMouseExited

    private void userRecordsBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userRecordsBtnMouseEntered
        userRecordsBtn.setBackground(new Color(190,54,56));
        jLabel15.setForeground(new Color(255,192,210));
        jLabel16.setIcon(setImage("src/images/user_icon_Hover.png", jLabel16));
    }//GEN-LAST:event_userRecordsBtnMouseEntered

    private void userRecordsBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userRecordsBtnMouseExited
        userRecordsBtn.setBackground(new Color(223,110,110));
        jLabel15.setForeground(new Color(255,255,255));
        jLabel16.setIcon(setImage("src/images/user_icon.png", jLabel16));
    }//GEN-LAST:event_userRecordsBtnMouseExited

    private void adminRecordsBtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminRecordsBtnMouseEntered
        adminRecordsBtn.setBackground(new Color(190,54,56));
        jLabel17.setForeground(new Color(255,192,210));
        jLabel18.setIcon(setImage("src/images/admin_icon_Hover.png", jLabel18));
    }//GEN-LAST:event_adminRecordsBtnMouseEntered

    private void adminRecordsBtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminRecordsBtnMouseExited
        adminRecordsBtn.setBackground(new Color(223,110,110));
        jLabel17.setForeground(new Color(255,255,255));
        jLabel18.setIcon(setImage("src/images/admin_icon.png", jLabel18));
    }//GEN-LAST:event_adminRecordsBtnMouseExited

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
         try {
            // Set the look-and-feel to FlatLightLaf
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>
        //</editor-fold>

        
        
        
        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                 
                new admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField adminIDInput;
    private javax.swing.JTextField adminNameInput;
    private javax.swing.JPasswordField adminPasswordInput;
    private javax.swing.JTextField adminPositionInput;
    private javax.swing.JPanel adminRecordsBtn;
    public javax.swing.JTable admin_info_table;
    private javax.swing.JPanel admin_records;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel clinic_logo;
    private javax.swing.JLabel close_label;
    private javax.swing.JPasswordField currentPasswordInput;
    private javax.swing.JPanel dashboard;
    private javax.swing.JPanel dashboardBtn;
    private com.toedter.calendar.JDateChooser endDateChooser;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel logo_label;
    private javax.swing.JPanel mainContentPanel;
    private javax.swing.JLabel minimize_label;
    private javax.swing.JPanel patientRecordsBtn;
    public javax.swing.JComboBox<String> patientTypeInput;
    private javax.swing.JComboBox<String> patientTypeInput1;
    private javax.swing.JPanel patient_records;
    private javax.swing.JTable patient_records_table;
    private javax.swing.JTextField searchIDInput;
    private javax.swing.JTextField searchIDInput1;
    private javax.swing.JLabel selectedID;
    private javax.swing.JLabel selectedID1;
    private javax.swing.JComboBox<String> sortInput;
    private com.toedter.calendar.JDateChooser startDateChooser;
    private javax.swing.JPanel userRecordsBtn;
    public javax.swing.JTable user_info_table;
    private javax.swing.JPanel user_records;
    private javax.swing.JLabel viewPassword;
    private javax.swing.JLabel viewPassword1;
    // End of variables declaration//GEN-END:variables
}
