/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package cvsu_clinic_system;

import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author basba
 */
public class edit_user_form extends javax.swing.JFrame {

    /**
     * Creates new form add_user_form
     */
    private String url = "jdbc:mysql://localhost:3306/clinic_system";
    private String sqlPass = "jmbasbas";
    private int mouseX, mouseY, selectedID;
    private admin originalFrame;
   
    public edit_user_form(admin originalFrame, int tabIndex, String selectedUserID, String selectedUserName, String selectedUserType, String selectedUserStrandDepartment, String selectedUserPositionSection) {
        this.originalFrame = originalFrame;
        selectedID = Integer.parseInt(selectedUserID);
        
        ImageIcon appIcon = new ImageIcon("src/images/clinic_logo.png");
        setIconImage(appIcon.getImage());
        setTitle("ALLSHS Clinic - Edit User");
        
        initComponents();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 35, 35));
        
        logo_label.setIcon(setImage("src/images/allshs_logo.jpg", logo_label));
        minimize_label.setIcon(setImage("src/images/minimize_icon.png", minimize_label));
        close_label.setIcon(setImage("src/images/close_icon.png", close_label));
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // Store initial mouse position when the mouse is pressed
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        // Add mouse motion listener for dragging
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                // Get the new mouse position
                int x = getLocation().x + e.getX() - mouseX;
                int y = getLocation().y + e.getY() - mouseY;

                // Set the new location of the frame
                setLocation(x, y);
            }
        });
        idInput.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
        idInput1.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
            }
        });
        jTabbedPane1.setSelectedIndex(tabIndex);
        
        switch (selectedUserType) {
            case "STUDENT":
                idInput.setText(selectedUserID);
                nameInput.setText(selectedUserName);
                strandInput.setSelectedItem(selectedUserStrandDepartment);
                String[] sectionParts = selectedUserPositionSection.split("-");
                gradeLevelInput.setSelectedItem(sectionParts[0].trim());
                sectionInput.setSelectedItem(sectionParts[1].trim());
                break;
            case "TEACHER":
                idInput1.setText(selectedUserID);
                nameInput1.setText(selectedUserName);
                departmentInput.setSelectedItem(selectedUserStrandDepartment);
                positionInput.setText(selectedUserPositionSection);
                break;
            case "SCHOOL STAFF":
                idInput2.setText(selectedUserID);
                nameInput2.setText(selectedUserName);
                departmentInput1.setSelectedItem(selectedUserStrandDepartment);
                positionInput1.setText(selectedUserPositionSection);
                break;
        }
        
    }
    
    public void updateDatabase() {
        if ("".equals(nameInput.getText()) || "".equals(idInput.getText())) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit user details?", "Submit User Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {

                int ID = Integer.parseInt(idInput.getText());
                String name = nameInput.getText();
                String strand = (String) strandInput.getSelectedItem();
                String section = (String) gradeLevelInput.getSelectedItem() + " - " + (String) sectionInput.getSelectedItem();

                try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                    String sql = "INSERT INTO user_info VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, ID);
                    stmt.setString(2, name);
                    stmt.setString(3, "STUDENT");
                    stmt.setString(4, strand);
                    stmt.setString(5, section);

                    int rowsInserted = stmt.executeUpdate();

                    stmt.close();
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage());
                }
                
                JOptionPane.showConfirmDialog(null, "User added to database!", "Submition Successful", JOptionPane.DEFAULT_OPTION);
              
            }
        }
    }

    ImageIcon setImage(String url, JLabel label) {

        ImageIcon img1 = new ImageIcon(url);
        Image img2 = img1.getImage();
        int hei = label.getHeight();
        int wid = label.getWidth();
        Image img3 = img2.getScaledInstance(wid, hei, wid);

        ImageIcon finalimg = new ImageIcon(img3);
        return finalimg;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        logo_label = new javax.swing.JLabel();
        minimize_label = new javax.swing.JLabel();
        close_label = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        idInput = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        nameInput = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        strandInput = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        sectionInput = new javax.swing.JComboBox<>();
        gradeLevelInput = new javax.swing.JComboBox<>();
        addButton = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        idInput1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        nameInput1 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        departmentInput = new javax.swing.JComboBox<>();
        positionInput = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        idInput2 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        nameInput2 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        departmentInput1 = new javax.swing.JComboBox<>();
        positionInput1 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(175, 82, 82));
        jLabel2.setText("ALLSHS CLINIC RECORDING SYSTEM");
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 452, -1));

        logo_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/allshs_logo.jpg"))); // NOI18N
        logo_label.setText("jLabel6");
        jPanel7.add(logo_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 55, 55));

        minimize_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/minimize_icon.png"))); // NOI18N
        minimize_label.setText("jLabel6");
        minimize_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimize_labelminimize_form(evt);
            }
        });
        jPanel7.add(minimize_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 20, 25, 25));

        close_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close_icon.png"))); // NOI18N
        close_label.setText("jLabel6");
        close_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close_labelclose_form(evt);
            }
        });
        jPanel7.add(close_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 20, 25, 25));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 70));

        jPanel2.setBackground(new java.awt.Color(223, 110, 110));

        jTabbedPane1.setBackground(new java.awt.Color(197, 70, 70));
        jTabbedPane1.setForeground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane1.setFocusable(false);
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(197, 70, 70));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("EDIT USER");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("(STUDENT)");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));
        jPanel1.add(idInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 410, 35));

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Student ID:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));
        jPanel1.add(nameInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 410, 35));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Name:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, -1, -1));

        strandInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Science Technology Engeneering and Mathematics", "Humanities and Social Sciences", "Acountancy", "Business and Management", "Information and Communication Technology", "Home Economics", "Industrial Arts (EIM)", "Industrial Arts (SMAW)" }));
        jPanel1.add(strandInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 410, 35));

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Strand:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, -1, -1));

        jLabel13.setBackground(new java.awt.Color(255, 255, 255));
        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Grade Level:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, -1, -1));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Section:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 310, -1, -1));

        sectionInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C", "D", "E", "F", "G", "H", " " }));
        jPanel1.add(sectionInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 330, 200, 35));

        gradeLevelInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "11", "12" }));
        jPanel1.add(gradeLevelInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, 200, 35));

        addButton.setBackground(new java.awt.Color(141, 31, 31));
        addButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        addButton.setForeground(new java.awt.Color(255, 255, 255));
        addButton.setText("EDIT");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        jPanel1.add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 130, 50));

        jTabbedPane1.addTab("STUDENT", jPanel1);

        jPanel3.setBackground(new java.awt.Color(197, 70, 70));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("EDIT USER");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("(TEACHER)");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, -1, -1));
        jPanel3.add(idInput1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 410, 35));

        jLabel19.setBackground(new java.awt.Color(255, 255, 255));
        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Employee ID:");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));
        jPanel3.add(nameInput1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 410, 35));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Name:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, -1, -1));

        jButton3.setBackground(new java.awt.Color(141, 31, 31));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("EDIT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 130, 50));

        departmentInput.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Math", "Science", "English", "Research", "Physical Education" }));
        jPanel3.add(departmentInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 410, 35));
        jPanel3.add(positionInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, 410, 35));

        jLabel21.setBackground(new java.awt.Color(255, 255, 255));
        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Position:");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, -1, -1));

        jLabel22.setBackground(new java.awt.Color(255, 255, 255));
        jLabel22.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Department:");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, -1, -1));

        jTabbedPane1.addTab("TEACHER", jPanel3);

        jPanel4.setBackground(new java.awt.Color(197, 70, 70));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("EDIT USER");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, -1, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("(SCHOOL STAFF)");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, -1, -1));
        jPanel4.add(idInput2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 410, 35));

        jLabel23.setBackground(new java.awt.Color(255, 255, 255));
        jLabel23.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Employee ID:");
        jPanel4.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));
        jPanel4.add(nameInput2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 410, 35));

        jLabel24.setBackground(new java.awt.Color(255, 255, 255));
        jLabel24.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Name:");
        jPanel4.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, -1, -1));

        jButton4.setBackground(new java.awt.Color(141, 31, 31));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("EDIT");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 130, 50));

        departmentInput1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Utility", "Security", "Canteen" }));
        jPanel4.add(departmentInput1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 410, 35));
        jPanel4.add(positionInput1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, 410, 35));

        jLabel25.setBackground(new java.awt.Color(255, 255, 255));
        jLabel25.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Position:");
        jPanel4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, -1, -1));

        jLabel26.setBackground(new java.awt.Color(255, 255, 255));
        jLabel26.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Department:");
        jPanel4.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, -1, -1));

        jTabbedPane1.addTab("SCHOOL STAFF", jPanel4);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 693, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 690, 480));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void minimize_labelminimize_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelminimize_form
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimize_labelminimize_form

    
    private void close_labelclose_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelclose_form
        this.dispose();
    }//GEN-LAST:event_close_labelclose_form

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        if ("".equals(nameInput.getText()) || "".equals(idInput.getText())) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit edit details?", "Edit User Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {
                try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);


                    String sql = "UPDATE user_info SET User_ID = ?, User_Name = ?, User_Strand_Department = ?, User_Position_Section = ? WHERE User_ID = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, Integer.parseInt(idInput.getText()));
                    stmt.setString(2, nameInput.getText());
                    stmt.setString(3, (String) strandInput.getSelectedItem());
                    stmt.setString(4, (String) gradeLevelInput.getSelectedItem() + " - " + (String) sectionInput.getSelectedItem());
                    stmt.setInt(5, selectedID);
                    
                    stmt.executeUpdate();

                    stmt.close();
                    conn.close();

                    // Call fetchAndUpdateTable() on the original JFrame
                    if (originalFrame != null) {
                        originalFrame.loadUserDataFromDatabase();
                    }

                    // Close the Add Form JFrame
                    this.dispose();

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                } 
                JOptionPane.showConfirmDialog(null, "Data edited successfully!", "Edit Successful", JOptionPane.DEFAULT_OPTION);

            }
        }

        
        
        
    }//GEN-LAST:event_addButtonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if ("".equals(nameInput1.getText()) || "".equals(idInput1.getText()) || "".equals(positionInput.getText())) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit user details?", "Submit User Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {

               try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                    String sql = "UPDATE user_info SET User_ID = ?, User_Name = ?, User_Strand_Department = ?, User_Position_Section = ? WHERE User_ID = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, Integer.parseInt(idInput1.getText()));
                    stmt.setString(2, nameInput1.getText());
                    stmt.setString(3, (String) departmentInput.getSelectedItem());
                    stmt.setString(4, positionInput.getText());
                    stmt.setInt(5, selectedID);

                    stmt.executeUpdate();

                    stmt.close();
                    conn.close();

                    JOptionPane.showMessageDialog(this, "Data added successfully!");

                    // Call fetchAndUpdateTable() on the original JFrame
                    if (originalFrame != null) {
                        originalFrame.loadUserDataFromDatabase();
                    }

                    // Close the Add Form JFrame
                    this.dispose();

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                } 
                JOptionPane.showConfirmDialog(null, "User added to database!", "Submition Successful", JOptionPane.DEFAULT_OPTION);

            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if ("".equals(nameInput2.getText()) || "".equals(idInput2.getText())) {
            JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int input = JOptionPane.showConfirmDialog(null, "Do you want to submit user details?", "Submit User Details", JOptionPane.YES_NO_OPTION);
            if(input == 0) {

               try {
                    Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                    String sql = "UPDATE user_info SET User_ID = ?, User_Name = ?, User_Strand_Department = ?, User_Position_Section = ? WHERE User_ID = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setInt(1, Integer.parseInt(idInput2.getText()));
                    stmt.setString(2, nameInput2.getText());
                    stmt.setString(3, (String) departmentInput1.getSelectedItem());
                    stmt.setString(4, positionInput1.getText());
                    stmt.setInt(5, selectedID);

                    stmt.executeUpdate();

                    stmt.close();
                    conn.close();

                    JOptionPane.showConfirmDialog(null, "Data added successfully!", "Submition Successful", JOptionPane.DEFAULT_OPTION);

                    // Call fetchAndUpdateTable() on the original JFrame
                    if (originalFrame != null) {
                        originalFrame.loadUserDataFromDatabase();
                    }

                    // Close the Add Form JFrame
                    this.dispose();

                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                } 
                

            }
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
         try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JLabel close_label;
    public javax.swing.JComboBox<String> departmentInput;
    public javax.swing.JComboBox<String> departmentInput1;
    public javax.swing.JComboBox<String> gradeLevelInput;
    private javax.swing.JTextField idInput;
    private javax.swing.JTextField idInput1;
    private javax.swing.JTextField idInput2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    public javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel logo_label;
    private javax.swing.JLabel minimize_label;
    private javax.swing.JTextField nameInput;
    private javax.swing.JTextField nameInput1;
    private javax.swing.JTextField nameInput2;
    public javax.swing.JTextField positionInput;
    public javax.swing.JTextField positionInput1;
    public javax.swing.JComboBox<String> sectionInput;
    public javax.swing.JComboBox<String> strandInput;
    // End of variables declaration//GEN-END:variables
}
