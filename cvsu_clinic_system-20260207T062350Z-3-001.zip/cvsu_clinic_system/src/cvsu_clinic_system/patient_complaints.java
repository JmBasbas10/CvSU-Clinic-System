/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cvsu_clinic_system;

/**
 *
 * @author basba
 */
public class patient_complaints {
    
    boolean nausea, fatigue, insomia, difficulty_breathing, stomach_problems, menstrual_problems, muscle_cramps, blurry_vision, backpain;
    String others;
    
    public patient_complaints(boolean nausea, boolean difficulty_breathing, boolean muscle_cramps, boolean fatigue, boolean stomach_problems, boolean blurry_vision, boolean insomia, boolean menstrual_problems, boolean backpain, String others){
        
        this.nausea = nausea;
        this.difficulty_breathing = difficulty_breathing;
        this.muscle_cramps = muscle_cramps;
        this.fatigue = fatigue;
        this.stomach_problems = stomach_problems;
        this.blurry_vision = blurry_vision;
        this.insomia = insomia;
        this.menstrual_problems = menstrual_problems;
        this.backpain = backpain;
        this.others = others;
    }
}
