/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package cvsu_clinic_system;

import com.formdev.flatlaf.themes.FlatMacLightLaf;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 *
 * @author basba
 */
public class patient_details_form extends javax.swing.JFrame {

    /**
     * Creates new form add_user_form
     */
    private String url = "jdbc:mysql://localhost:3306/clinic_system";
    private String sqlPass = "jmbasbas";
    public int mouseX, mouseY, ID, age, recordID;
    public String type, name, sex, strandDpartment, positionSection; 
    
    
    
    public patient_details_form(int recordID, int ID, String type, String name, int age, String sex, String strandDepartment, String positionSection, String recordDate, String patientStatus) {
        
        ImageIcon appIcon = new ImageIcon("src/images/clinic_logo.png");
        setIconImage(appIcon.getImage());
        setTitle("ALLSHS Clinic - Patient Details");
        
        initComponents();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 35, 35));
        jRadioButton2.setSelected(true);
        this.recordID = recordID;
        patientIDLabel.setText(String.valueOf(ID));
        patientTypeLabel.setText(type);
        patientNameLabel.setText(name);
        patientAgeLabel.setText(String.valueOf(age));
        patientSexLabel.setText(sex);
        strandDepartmentLabel.setText(strandDepartment);
        positionSectionLabel.setText(positionSection);
        recordDateLabel.setText(recordDate);
        statusLabel.setText(patientStatus);
        
        if ("DIAGNOSED".equals(patientStatus)) {
            bpInput1.setEnabled(false);
            bpInput2.setEnabled(false);
            tempInput.setEnabled(false);
            remarksInput.setEnabled(false);
            jRadioButton2.setEnabled(false);
            jRadioButton4.setEnabled(false);
            jRadioButton5.setEnabled(false);
            
            try {
                Connection conn = DriverManager.getConnection(url, "root", sqlPass);
                PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_diagnosis WHERE Patient_Record_ID = ?");
                stmt.setInt(1, recordID);
                ResultSet rs = stmt.executeQuery();

                if(rs.next()) {
                    String bp = rs.getString("Patient_BP");
                    String intervention = rs.getString("Patient_Intervention");
                    
                    String[] sectionParts = bp.split("/");
                    bpInput1.setValue(Integer.parseInt(sectionParts[0].trim()));
                    bpInput2.setValue(Integer.parseInt(sectionParts[1].trim()));
                    switch (intervention) {
                        case "N/A":
                            jRadioButton2.setSelected(true);
                            break;
                        case "Medecine":
                            jRadioButton5.setSelected(true);
                            break;
                        case "Rest":
                            jRadioButton4.setSelected(true);
                            break;
                    }
                    
                    remarksInput.setText(rs.getString("Patient_Remarks"));
                } 



                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }  
            
        }
        
        logo_label.setIcon(setImage("src/images/allshs_logo.jpg", logo_label));
        minimize_label.setIcon(setImage("src/images/minimize_icon.png", minimize_label));
        close_label.setIcon(setImage("src/images/close_icon.png", close_label));
        
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                // Store initial mouse position when the mouse is pressed
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });

        // Add mouse motion listener for dragging
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                // Get the new mouse position
                int x = getLocation().x + e.getX() - mouseX;
                int y = getLocation().y + e.getY() - mouseY;

                // Set the new location of the frame
                setLocation(x, y);
            }
        });
        loadCompList(recordID);
         JSpinner.DefaultEditor bpOverEditor = (JSpinner.DefaultEditor) bpInput1.getEditor();
        JFormattedTextField bpOverTextField = bpOverEditor.getTextField();
        bpOverTextField.setEditable(false); 
        bpOverEditor.setFocusable(false); 
        
        JSpinner.DefaultEditor bpUnderEditor = (JSpinner.DefaultEditor) bpInput2.getEditor();
        JFormattedTextField bpUnderTextField = bpUnderEditor.getTextField();
        bpUnderTextField.setEditable(false); 
        bpUnderEditor.setFocusable(false); 
        
        JSpinner.DefaultEditor tempEditor = (JSpinner.DefaultEditor) tempInput.getEditor();
        JFormattedTextField tempTextField = tempEditor.getTextField();
        tempTextField.setEditable(false); 
        tempEditor.setFocusable(false); 
        strandDepartmentLabel.setPreferredSize(new Dimension(178, 20));  
        strandDepartmentLabel.setToolTipText(strandDepartmentLabel.getText());
        
        submitButton.addActionListener(i -> {
            if ("DIAGNOSED".equals(patientStatus)) { 
                JOptionPane.showMessageDialog(null, "Patient is already diagnosed!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if((int) bpInput1.getValue() == 0 || (int)bpInput2.getValue() == 0 || (int)tempInput.getValue() == 0 || "".equals(remarksInput.getText())) {
                JOptionPane.showMessageDialog(null, "Fill in all inputs!", "Error", JOptionPane.ERROR_MESSAGE);
            } else if ("UNDIAGNOSED".equals(patientStatus)) {
                int input = JOptionPane.showConfirmDialog(null, "Do you want to submit diagnosis?", "Submit Diagnosis", JOptionPane.YES_NO_OPTION);
                if(input == 0) {
                    String bp =  bpInput1.getValue() + " / " +  bpInput2.getValue();
                    int temp = (int) tempInput.getValue();
                    String remarks = remarksInput.getText();
                    try {
                        Connection conn = DriverManager.getConnection(url, "root", sqlPass);

                        String sql = "INSERT INTO patient_diagnosis(Patient_Record_ID, Patient_BP, Patient_Temp, Patient_Intervention, Patient_Remarks) values(?, ?, ?, ?, ?)";
                        PreparedStatement stmt = conn.prepareStatement(sql);


                        stmt.setInt(1, recordID);
                        stmt.setString(2, bp);
                        stmt.setInt(3, temp);
                        stmt.setString(4, getSelectedButtonText(buttonGroup1));
                        stmt.setString(5, remarks);

                        stmt.executeUpdate();

                        stmt = conn.prepareStatement("UPDATE patient_records SET Patient_Record_Status = 'DIAGNOSED'  where (Patient_Record_ID = ?);");

                        stmt.setInt(1, recordID);

                        stmt.executeUpdate();
                        stmt.close();
                        conn.close();

                        JOptionPane.showMessageDialog(this, "Patient diagnosed successfully!");

                    } catch (SQLException e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                    } 
                }

        }
            
        });
    }
    
    public static String getSelectedButtonText(ButtonGroup group) {
        for (Enumeration<AbstractButton> buttons = group.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();
            if (button.isSelected()) {
                return button.getText();
            }
        }
        return "N/A";
    }
    
    private void loadCompList(int recordID) {
        DefaultListModel model = new DefaultListModel();
        
        try {
            Connection conn = DriverManager.getConnection(url, "root", sqlPass);
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patient_complaints WHERE Patient_Record_ID = ?");
            stmt.setInt(1, recordID);
            ResultSet rs = stmt.executeQuery();
            
            
            
            
            if(rs.next()) {
               boolean nausea = rs.getBoolean("Comp_Nausea");
               if(nausea) {
                   model.addElement("Nausea");
               }
               boolean Difficulty_Breathing = rs.getBoolean("Comp_Difficulty_Breathing");
               if(Difficulty_Breathing) {
                   model.addElement("Difficulty Breathing");
               }
               boolean Muscle_Cramps = rs.getBoolean("Comp_Muscle_Cramps");
               if(Muscle_Cramps) {
                   model.addElement("Muscle Cramps");
               }
               boolean Fatigue = rs.getBoolean("Comp_Fatigue");
               if(Fatigue) {
                   model.addElement("Fatigue");
               }
               boolean Stomach_Problems = rs.getBoolean("Comp_Stomach_Problems");
               if(Stomach_Problems) {
                   model.addElement("Stomach Problems");
               }
               boolean Blurry_Vision  = rs.getBoolean("Comp_Blurry_Vision");
               if(Blurry_Vision) {
                   model.addElement("Blurry Vision");
               }
               boolean Insomia = rs.getBoolean("Comp_Insomia");
               if(Insomia) {
                   model.addElement("Insomia");
               }
               boolean Menstrual_Problems = rs.getBoolean("Comp_Menstrual_Problems");
               if(Menstrual_Problems) {
                   model.addElement("Menstrual Problems");
               }
               boolean Backpain = rs.getBoolean("Comp_Backpain");
               if(Backpain) {
                   model.addElement("Backpain");
               }
               compList.setModel(model);
            } else {
                System.out.println("h");
            }


            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();

        }   
        
    }
    
    ImageIcon setImage(String url, JLabel label) {

        ImageIcon img1 = new ImageIcon(url);
        Image img2 = img1.getImage();
        int hei = label.getHeight();
        int wid = label.getWidth();
        Image img3 = img2.getScaledInstance(wid, hei, wid);

        ImageIcon finalimg = new ImageIcon(img3);
        return finalimg;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        logo_label = new javax.swing.JLabel();
        minimize_label = new javax.swing.JLabel();
        close_label = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        compList = new javax.swing.JList<>();
        jLabel11 = new javax.swing.JLabel();
        patientIDLabel = new javax.swing.JLabel();
        patientTypeLabel = new javax.swing.JLabel();
        patientNameLabel = new javax.swing.JLabel();
        patientAgeLabel = new javax.swing.JLabel();
        patientSexLabel = new javax.swing.JLabel();
        strandDepartmentLabel = new javax.swing.JLabel();
        positionSectionLabel = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        bpInput1 = new javax.swing.JSpinner();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        bpInput2 = new javax.swing.JSpinner();
        jLabel19 = new javax.swing.JLabel();
        tempInput = new javax.swing.JSpinner();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        remarksInput = new javax.swing.JTextArea();
        submitButton = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        recordDateLabel = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        statusLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(175, 82, 82));
        jLabel2.setText("ALLSHS CLINIC RECORDING SYSTEM");
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 452, -1));

        logo_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/allshs_logo.jpg"))); // NOI18N
        logo_label.setText("jLabel6");
        jPanel7.add(logo_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 55, 55));

        minimize_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/minimize_icon.png"))); // NOI18N
        minimize_label.setText("jLabel6");
        minimize_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                minimize_labelminimize_form(evt);
            }
        });
        jPanel7.add(minimize_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 20, 25, 25));

        close_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close_icon.png"))); // NOI18N
        close_label.setText("jLabel6");
        close_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close_labelclose_form(evt);
            }
        });
        jPanel7.add(close_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 20, 25, 25));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 70));

        jPanel2.setBackground(new java.awt.Color(197, 70, 70));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("PATIENT DETAILS");

        jPanel1.setBackground(new java.awt.Color(166, 36, 36));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 35, 35));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("PATIENT PROFILE");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Patient ID:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Patient Type:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Patient Name:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Patient Age:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Patient Sex:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Strand / Dept:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Position / Section:");

        compList.setBackground(new java.awt.Color(255, 124, 124));
        compList.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        compList.setForeground(new java.awt.Color(255, 255, 255));
        compList.setFocusable(false);
        jScrollPane1.setViewportView(compList);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Complaints:");

        patientIDLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        patientIDLabel.setForeground(new java.awt.Color(255, 255, 255));
        patientIDLabel.setText("Patient ID Label");

        patientTypeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        patientTypeLabel.setForeground(new java.awt.Color(255, 255, 255));
        patientTypeLabel.setText("Patient Type Label");

        patientNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        patientNameLabel.setForeground(new java.awt.Color(255, 255, 255));
        patientNameLabel.setText("Patient Name Label");

        patientAgeLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        patientAgeLabel.setForeground(new java.awt.Color(255, 255, 255));
        patientAgeLabel.setText("Patient Age Label");

        patientSexLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        patientSexLabel.setForeground(new java.awt.Color(255, 255, 255));
        patientSexLabel.setText("Patient Sex Label");

        strandDepartmentLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        strandDepartmentLabel.setForeground(new java.awt.Color(255, 255, 255));
        strandDepartmentLabel.setText("Strand / Department Label");
        strandDepartmentLabel.setMaximumSize(new java.awt.Dimension(300, 22));
        strandDepartmentLabel.setMinimumSize(new java.awt.Dimension(300, 22));
        strandDepartmentLabel.setPreferredSize(new java.awt.Dimension(300, 22));

        positionSectionLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        positionSectionLabel.setForeground(new java.awt.Color(255, 255, 255));
        positionSectionLabel.setText("Position / Section Label");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jLabel6))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(patientTypeLabel))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(patientIDLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(patientNameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(patientAgeLabel))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(patientSexLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(strandDepartmentLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(positionSectionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(patientIDLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(patientTypeLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(patientNameLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(patientAgeLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(patientSexLabel))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(strandDepartmentLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(positionSectionLabel))
                .addGap(16, 16, 16)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(166, 36, 36));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText(" VITAL SIGNS");

        bpInput1.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));
        bpInput1.setFocusable(false);

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Blood Pressure:");

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("/");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Temparature");

        tempInput.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("C°");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("mmHg");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addComponent(jLabel19)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(bpInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(jLabel18)
                                .addGap(18, 18, 18)
                                .addComponent(bpInput2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel22))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(tempInput, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel20)))))
                .addContainerGap(88, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bpInput1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18)
                            .addComponent(bpInput2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(16, 16, 16)))
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tempInput, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(166, 36, 36));
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("INTERVENTION");

        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton2.setText("N/A");

        buttonGroup1.add(jRadioButton4);
        jRadioButton4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRadioButton4.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton4.setText("Rest");

        buttonGroup1.add(jRadioButton5);
        jRadioButton5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jRadioButton5.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton5.setText("Medecine");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jRadioButton2)
                        .addGap(55, 55, 55)
                        .addComponent(jRadioButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jRadioButton4)
                        .addGap(40, 40, 40))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel21)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButton2)
                    .addComponent(jRadioButton5)
                    .addComponent(jRadioButton4))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jPanel10.setBackground(new java.awt.Color(166, 36, 36));
        jPanel10.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("REMARKS");

        remarksInput.setColumns(20);
        remarksInput.setRows(5);
        jScrollPane2.setViewportView(remarksInput);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel24))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        submitButton.setBackground(new java.awt.Color(141, 31, 31));
        submitButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        submitButton.setForeground(new java.awt.Color(255, 255, 255));
        submitButton.setText("SUBMIT");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(141, 31, 31));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("PRINT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        recordDateLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        recordDateLabel.setForeground(new java.awt.Color(255, 255, 255));
        recordDateLabel.setText("Record Date Label");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Record Date:");

        statusLabel.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        statusLabel.setForeground(new java.awt.Color(255, 255, 255));
        statusLabel.setText("Patient Status Label");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(submitButton, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)
                            .addComponent(recordDateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12)
                            .addComponent(statusLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel5))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(recordDateLabel)
                                .addGap(63, 63, 63)
                                .addComponent(statusLabel)
                                .addGap(55, 55, 55))
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 1060, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void minimize_labelminimize_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_labelminimize_form
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimize_labelminimize_form

    
    private void close_labelclose_form(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close_labelclose_form
        this.dispose();
    }//GEN-LAST:event_close_labelclose_form

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        
        
    }//GEN-LAST:event_submitButtonActionPerformed
    public static List<String> getJListValues(JList<String> list) {
        List<String> values = new ArrayList<>();
        for (int i = 0; i < list.getModel().getSize(); i++) {
            values.add(list.getModel().getElementAt(i));
        }
        return values;
    }
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            String patientID = patientIDLabel.getText();
            String patientType = patientTypeLabel.getText();
            String patientName = patientNameLabel.getText();
            String patientAge = patientAgeLabel.getText();
            String patientSex = patientSexLabel.getText();
            String patientStrandDepartment = strandDepartmentLabel.getText();
            String patientPositionSection = positionSectionLabel.getText();
            String patientRecordDate = recordDateLabel.getText();
            List<String> patientComplaintsList = getJListValues(compList);
            String patientBP = bpInput1.getValue() + " / " + bpInput2.getValue();
            String patientTemp = tempInput.getValue().toString();
            String patientIntervention =  getSelectedButtonText(buttonGroup1);
            String patientRemarks = remarksInput.getText();
            
            printToPDF.exportPatientReportToPDF(
                    "C:\\Users\\basba\\Desktop\\Patient_Report_RecordID" + recordID +".pdf", 
                    patientID, 
                    patientType, 
                    patientName, 
                    patientAge, 
                    patientSex, 
                    patientStrandDepartment, 
                    patientPositionSection, 
                    patientRecordDate, 
                    patientComplaintsList, 
                    patientBP, patientTemp, 
                    patientIntervention, 
                    patientRemarks);
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
         try {
            UIManager.setLookAndFeel(new FlatMacLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner bpInput1;
    private javax.swing.JSpinner bpInput2;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel close_label;
    private javax.swing.JList<String> compList;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel logo_label;
    private javax.swing.JLabel minimize_label;
    public javax.swing.JLabel patientAgeLabel;
    public javax.swing.JLabel patientIDLabel;
    public javax.swing.JLabel patientNameLabel;
    public javax.swing.JLabel patientSexLabel;
    public javax.swing.JLabel patientTypeLabel;
    public javax.swing.JLabel positionSectionLabel;
    public javax.swing.JLabel recordDateLabel;
    private javax.swing.JTextArea remarksInput;
    public javax.swing.JLabel statusLabel;
    public javax.swing.JLabel strandDepartmentLabel;
    private javax.swing.JButton submitButton;
    private javax.swing.JSpinner tempInput;
    // End of variables declaration//GEN-END:variables
}
