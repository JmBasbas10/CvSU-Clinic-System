/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cvsu_clinic_system;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.LineSeparator;
import java.io.File;
import java.io.FileNotFoundException;
import javax.swing.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class printToPDF {
    
 
    public static void exportTableToPDF(JTable table, String filename) {
        try {
            
            
            // Check if the file exists, and if so, modify the filename using a counter
            File file = new File(filename);
            int counter = 1;
            String newFilename = filename;

            // If the file already exists, append a counter to the filename
            while (file.exists()) {
                newFilename = filename.replace(".pdf", "_" + counter + ".pdf");
                file = new File(newFilename);
                counter++;
            }

            // Now newFilename is unique, so use it for the output file
            filename = newFilename;
            
            // Create the PDF document
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(filename));
            document.open();

            // Adding the school header with logo, name, and address
            Image logo = Image.getInstance("src/images/allshs_logo.jpg"); // Replace with your image path
            logo.scaleAbsolute(70, 70); // Resize the logo

            // School name and address
            Font schoolNameFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.BLACK);
            Font addressFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Paragraph schoolName = new Paragraph("Angelo Levardo Loyola Senior Highschool", schoolNameFont);
            Paragraph schoolAddress = new Paragraph("172WX+WCQ, Alfonso Macha St, Carmona, Cavite", addressFont);

            // Aligning the school header with logo
            PdfPTable schoolHeaderTable = new PdfPTable(2);
            schoolHeaderTable.setWidthPercentage(100);
            schoolHeaderTable.setWidths(new float[]{1, 3}); // Logo 1 part, text 3 parts

            PdfPCell logoCell = new PdfPCell(logo);
            logoCell.setBorder(Rectangle.NO_BORDER);
            logoCell.setHorizontalAlignment(Element.ALIGN_LEFT);

            PdfPCell schoolTextCell = new PdfPCell();
            schoolTextCell.addElement(schoolName);
            schoolTextCell.addElement(schoolAddress);
            schoolTextCell.setBorder(Rectangle.NO_BORDER);
            schoolTextCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            schoolTextCell.setHorizontalAlignment(Element.ALIGN_CENTER);

            schoolHeaderTable.addCell(logoCell);
            schoolHeaderTable.addCell(schoolTextCell);
            document.add(schoolHeaderTable);
            document.add(new Paragraph("\n")); 

            // Title and Date Section
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
            Paragraph title = new Paragraph("Patient Records Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);
            Paragraph date = new Paragraph("Generated on: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")), dateFont);
            date.setAlignment(Element.ALIGN_RIGHT);
            document.add(date);
            document.add(new Paragraph("\n"));

            // Data Description
            Font descriptionFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.DARK_GRAY);
            Paragraph description = new Paragraph(
                    "This report provides an overview of user information, including User ID, Name, Type, Strand/Department, and Position/Section. "
                            + "The data reflects the current state as of the generation date above.",
                    descriptionFont);
            description.setAlignment(Element.ALIGN_JUSTIFIED);
            description.setSpacingAfter(15f);
            document.add(description);

            // **Creating PDF Table with Page Continuation Support**
            PdfPTable pdfTable = new PdfPTable(table.getColumnCount());
            pdfTable.setWidthPercentage(100);
            pdfTable.setSpacingBefore(10f);
            pdfTable.setSpacingAfter(10f);
            pdfTable.setHeaderRows(1); // Keep the header on every new page

            // Adjust Column Widths
            float[] columnWidths = new float[table.getColumnCount()];
            for (int i = 0; i < columnWidths.length; i++) {
                columnWidths[i] = 2f;
            }
            pdfTable.setWidths(columnWidths);

            // Header Styling
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, BaseColor.WHITE);
            BaseColor headerBackgroundColor = new BaseColor(204, 0, 0); // Dark Red
            for (int i = 0; i < table.getColumnCount(); i++) {
                PdfPCell headerCell = new PdfPCell(new Phrase(table.getColumnName(i), headerFont));
                headerCell.setBackgroundColor(headerBackgroundColor);
                headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                headerCell.setPadding(8);
                pdfTable.addCell(headerCell);
            }

            // Table Data Styling with Alternating Row Colors
            Font cellFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
            BaseColor lightRed = new BaseColor(255, 204, 204); 
            for (int row = 0; row < table.getRowCount(); row++) {
                for (int col = 0; col < table.getColumnCount(); col++) {
                    PdfPCell dataCell = new PdfPCell(new Phrase(table.getValueAt(row, col).toString(), cellFont));
                    dataCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                    dataCell.setPadding(5);
                    dataCell.setBackgroundColor(row % 2 == 0 ? BaseColor.WHITE : lightRed);
                    pdfTable.addCell(dataCell);
                }
            }

            // Adding the table to the document
            document.add(pdfTable);

            // Footer Section
            document.add(new Paragraph("\n\n"));
            Font footerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.RED);
            Paragraph footer = new Paragraph("This report was generated using iTextPDF for Java.", footerFont);
            footer.setAlignment(Element.ALIGN_CENTER);
            document.add(footer);

            // Closing the document
            document.close();
            JOptionPane.showMessageDialog(null, "PDF created successfully!");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating PDF: " + e.getMessage());
        }
    }
    
 public static void exportPatientReportToPDF(
        String filename,
        String patientID,
        String patientType,
        String patientName,
        String patientAge,
        String patientSex,
        String patientStrandDepartment,
        String patientPositionSection,
        String patientRecordDate,
        List<String> patientComplaintsList,
        String patientBP,
        String patientTemp,
        String patientIntervention,
        String patientRemarks) {

        try {
            // Check if the file exists, and if so, modify the filename using a counter
            File file = new File(filename);
            int counter = 1;
            String newFilename = filename;

            // If the file already exists, append a counter to the filename
            while (file.exists()) {
                newFilename = filename.replace(".pdf", "_" + counter + ".pdf");
                file = new File(newFilename);
                counter++;
            }

            // Now newFilename is unique, so use it for the output file
            filename = newFilename;
            
            
            // Initialize PDF Document
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(filename));
            document.open();
            
            Image logo = Image.getInstance("src/images/allshs_logo.jpg"); // Replace with your image path
            logo.scaleAbsolute(70, 70);
            
            Font schoolNameFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.BLACK);
            Font addressFont = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL);
            Paragraph schoolName = new Paragraph("Angelo Levardo Loyola Senior Highschool", schoolNameFont);
            Paragraph schoolAddress = new Paragraph("172WX+WCQ, Alfonso Macha St, Carmona, Cavite", addressFont);

            PdfPTable schoolHeaderTable = new PdfPTable(2);
            schoolHeaderTable.setWidthPercentage(100);
            schoolHeaderTable.setWidths(new float[]{1, 3}); 

            PdfPCell logoCell = new PdfPCell(logo);
            logoCell.setBorder(Rectangle.NO_BORDER);
            logoCell.setHorizontalAlignment(Element.ALIGN_LEFT);

            PdfPCell schoolTextCell = new PdfPCell();
            schoolTextCell.addElement(schoolName);
            schoolTextCell.addElement(schoolAddress);
            schoolTextCell.setBorder(Rectangle.NO_BORDER);
            schoolTextCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            schoolTextCell.setHorizontalAlignment(Element.ALIGN_CENTER);

            schoolHeaderTable.addCell(logoCell);
            schoolHeaderTable.addCell(schoolTextCell);
            document.add(schoolHeaderTable);
            document.add(new Paragraph("\n")); 

            // Add a separator line (red color)
            LineSeparator separator = new LineSeparator();
            separator.setLineColor(BaseColor.RED);
            document.add(separator);

            // **Title Section**
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.BLACK);
            Paragraph title = new Paragraph("Patient Medical Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(new Paragraph("\n"));
            
            Font dateFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);
            Paragraph date = new Paragraph("Generated on: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM dd, yyyy")), dateFont);
            date.setAlignment(Element.ALIGN_RIGHT);
            document.add(date);
            document.add(new Paragraph("\n"));

            // **Patient Profile Section**
            Font sectionFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
            document.add(new Paragraph("Patient Profile", sectionFont));
            document.add(new Paragraph("\n"));

            document.add(new Paragraph("Patient ID: " + patientID));
            document.add(new Paragraph("Patient Type: " + patientType));
            document.add(new Paragraph("Patient Name: " + patientName));
            document.add(new Paragraph("Patient Age: " + patientAge));
            document.add(new Paragraph("Patient Sex: " + patientSex));
            document.add(new Paragraph("Strand/Department: " + patientStrandDepartment));
            document.add(new Paragraph("Position/Section: " + patientPositionSection));
            document.add(new Paragraph("Record Date: " + patientRecordDate));
            document.add(new Paragraph("\n"));

            // **Patient Complaints Section**
            document.add(new Paragraph("Patient Complaints", sectionFont));
            document.add(new Paragraph("\n"));

            for (String complaint : patientComplaintsList) {
                document.add(new Paragraph("- " + complaint));
            }
            document.add(new Paragraph("\n"));

            // **Patient Diagnosis Section**
            document.add(new Paragraph("Patient Diagnosis", sectionFont));
            document.add(new Paragraph("\n"));

            document.add(new Paragraph("Blood Pressure: " + patientBP));
            document.add(new Paragraph("Temperature: " + patientTemp));
            document.add(new Paragraph("Intervention: " + patientIntervention));
            document.add(new Paragraph("Remarks: " + patientRemarks));

            // Close the document
            document.close();
            JOptionPane.showMessageDialog(null, "PDF Created Successfully!");

        } catch (DocumentException | FileNotFoundException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error generating PDF: " + e.getMessage());
        } catch (IOException ex) {
            Logger.getLogger(printToPDF.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

    
}
